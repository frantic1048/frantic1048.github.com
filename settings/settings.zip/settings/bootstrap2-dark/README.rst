Bootstrap 2 Dark theme
==================

This theme is modified from `Bootstrap2 <https://github.com/getpelican/pelican-themes/tree/master/bootstrap2>`_ theme.

Also you can see its result from `my Github Page <http://frantic1048.github.io>`_. It will be updated using latest theme.

Feel free to use it.