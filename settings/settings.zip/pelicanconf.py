#!/usr/bin/env python
# -*- coding: utf-8 -*- #
from __future__ import unicode_literals

AUTHOR = u'Frantic1048'
SITENAME = u"Frantic World"
SITEURL = 'http://frantic1048.com'

DISQUS_SITENAME = u"frantic1048"
THEME = "bootstrap2"
STATIC_PATHS = [u"img"]


TIMEZONE = 'Asia/Shanghai'

DEFAULT_LANG = u'zh'

# Feed generation is usually not desired when developing
FEED_ALL_ATOM = None
CATEGORY_FEED_ATOM = None
TRANSLATION_FEED_ATOM = None

# Blogroll
LINKS =  (("cold", 'http://linuxzen.com/'),)

# Social widget
SOCIAL = (('Tudou', 'http://tudou.com/home/FranticBlack'),)

DEFAULT_PAGINATION = 10

# Uncomment following line if you want document-relative URLs when developing
#RELATIVE_URLS = True
